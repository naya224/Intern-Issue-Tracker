
package com.example.issuetrackingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class IssueStatusEntry(
    val status: String = "",
    val changedBy: String = "",
    val changedAt: Long = 0L
)

data class Issue(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val reporterUid: String = "",
    val reporterEmail: String = "",
    val status: String = "Pending",
    val priority: String = "Medium",
    val createdAt: Long = 0L,
    val statusHistory: List<IssueStatusEntry> = emptyList()
)

data class TicketComment(
    val id: String = "",
    val message: String = "",
    val senderEmail: String = "",
    val senderRole: String = "",
    val createdAt: Long = 0L
)

fun formatIssueDate(time: Long): String {
    if (time == 0L) return "Date not available"
    return SimpleDateFormat(
        "dd MMM yyyy, hh:mm a",
        Locale.getDefault()
    ).format(Date(time))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                IssueTrackingApp()
            }
        }
    }
}

@Composable
fun IssueTrackingApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }

    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var userRole by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("Home") }
    var issues by remember { mutableStateOf(listOf<Issue>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(currentUser?.uid) {
        val user = currentUser

        if (user == null) {
            userRole = ""
            return@LaunchedEffect
        }

        userRole = ""

        db.collection("users").document(user.uid).get()
            .addOnSuccessListener {
                userRole = it.getString("role") ?: "intern"
            }
            .addOnFailureListener {
                error = it.message ?: "Status update failed"
            }
    }

    DisposableEffect(currentUser?.uid, userRole) {
        var registration: ListenerRegistration? = null
        val user = currentUser

        if (user != null && userRole.isNotEmpty()) {
            registration = db.collection("issues")
                .addSnapshotListener { snapshot, exception ->

                    if (exception != null) {
                        error = exception.message ?: "Issue loading failed"
                    } else if (snapshot != null) {

                        val allIssues = snapshot.documents.map { doc ->

                            val timestamp = doc.getTimestamp("createdAt")

                            val history = (doc.get("statusHistory") as? List<*>)
                                ?.mapNotNull { item ->
                                    val map = item as? Map<*, *> ?: return@mapNotNull null
                                    val changedAt = map["changedAt"] as? Timestamp

                                    IssueStatusEntry(
                                        status = map["status"] as? String ?: "",
                                        changedBy = map["changedBy"] as? String ?: "",
                                        changedAt = changedAt?.toDate()?.time ?: 0L
                                    )
                                } ?: emptyList()

                            Issue(
                                id = doc.id,
                                title = doc.getString("title") ?: "",
                                description = doc.getString("description") ?: "",
                                reporterUid = doc.getString("reporterUid") ?: "",
                                reporterEmail = doc.getString("reporterEmail") ?: "",
                                status = doc.getString("status") ?: "Pending",
                                priority = doc.getString("priority") ?: "Medium",
                                createdAt = timestamp?.toDate()?.time ?: 0L,
                                statusHistory = history
                            )
                        }

                        issues = if (userRole == "admin") {
                            allIssues
                        } else {
                            allIssues.filter { it.reporterUid == user.uid }
                        }
                    }
                }
        }

        onDispose {
            registration?.remove()
        }
    }

    if (currentUser == null) {
        AuthScreen(
            onLogin = { email, password, callback ->
                auth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        currentUser = it.user
                        callback(true, "")
                    }
                    .addOnFailureListener {
                        callback(false, it.message ?: "Login failed")
                    }
            },
            onSignup = { email, password, callback ->
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnSuccessListener { result ->

                        val user = result.user

                        if (user == null) {
                            callback(false, "Account creation failed")
                            return@addOnSuccessListener
                        }

                        val data = hashMapOf(
                            "email" to email,
                            "role" to "intern",
                            "createdAt" to FieldValue.serverTimestamp()
                        )

                        db.collection("users").document(user.uid).set(data)
                            .addOnSuccessListener {
                                currentUser = user
                                callback(true, "")
                            }
                            .addOnFailureListener {
                                callback(false, it.message ?: "Profile save failed")
                            }
                    }
                    .addOnFailureListener {
                        callback(false, it.message ?: "Signup failed")
                    }
            }
        )
        return
    }

    if (userRole.isEmpty()) {
        Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = screen == "Home",
                    onClick = { screen = "Home" },
                    icon = { Text("⌂") },
                    label = { Text("Home") }
                )

                NavigationBarItem(
                    selected = screen == "Report",
                    onClick = { screen = "Report" },
                    icon = { Text("+") },
                    label = { Text("Report") }
                )

                NavigationBarItem(
                    selected = screen == "Tickets",
                    onClick = { screen = "Tickets" },
                    icon = { Text("▤") },
                    label = { Text("My Tickets") }
                )

                if (userRole == "admin") {
                    NavigationBarItem(
                        selected = screen == "Admin",
                        onClick = { screen = "Admin" },
                        icon = { Text("⚙") },
                        label = { Text("Admin") }
                    )
                }
            }
        }
    ) { padding ->

        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    currentUser?.email ?: "",
                    modifier = Modifier.weight(1f)
                )

                TextButton(
                    onClick = {
                        auth.signOut()
                        currentUser = null
                        userRole = ""
                        issues = emptyList()
                        screen = "Home"
                        error = ""
                    }
                ) {
                    Text("Logout")
                }
            }

            if (error.isNotEmpty()) {
                Text(
                    error,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Box(Modifier.weight(1f)) {
                when (screen) {

                    "Home" -> HomeScreen(
                        issues = issues,
                        onReport = { screen = "Report" },
                        onTickets = { screen = "Tickets" }
                    )

                    "Report" -> ReportScreen(
                        onSubmit = { title, description, priority ->

                            val user = auth.currentUser

                            if (user == null) {
                                error = "Please login first"
                            } else {
                                loading = true
                                error = ""

                                val initialHistory = mapOf(
                                    "status" to "Pending",
                                    "changedBy" to (user.email ?: "Intern"),
                                    "changedAt" to Timestamp.now()
                                )

                                val data = hashMapOf(
                                    "title" to title,
                                    "description" to description,
                                    "reporterUid" to user.uid,
                                    "reporterEmail" to (user.email ?: ""),
                                    "status" to "Pending",
                                    "priority" to priority,
                                    "createdAt" to FieldValue.serverTimestamp(),
                                    "statusHistory" to listOf(initialHistory)
                                )

                                db.collection("issues").add(data)
                                    .addOnSuccessListener {
                                        loading = false
                                        screen = "Tickets"
                                    }
                                    .addOnFailureListener {
                                        loading = false
                                        error = it.message ?: "Submission failed"
                                    }
                            }
                        },
                        loading
                    )

                    "Tickets" -> TicketsScreen(
                        issues = issues,
                        db = db,
                        userEmail = currentUser?.email ?: "",
                        userRole = userRole
                    )

                    "Admin" -> if (userRole == "admin") {
                        AdminScreen(
                            issues = issues,
                            db = db,
                            userEmail = currentUser?.email ?: "",
                            userRole = userRole,
                            onStatusChange = { id, status ->

                                val historyEntry = mapOf(
                                    "status" to status,
                                    "changedBy" to (currentUser?.email ?: "Admin"),
                                    "changedAt" to Timestamp.now()
                                )

                                db.collection("issues").document(id)
                                    .update(
                                        mapOf(
                                            "status" to status,
                                            "statusHistory" to FieldValue.arrayUnion(historyEntry)
                                        )
                                    )
                                    .addOnFailureListener {
                                        error = it.message ?: "Status update failed"
                                    }
                            },
                            onDelete = { id ->
                                db.collection("issues").document(id).delete()
                                    .addOnFailureListener {
                                        error = it.message ?: "Delete failed"
                                    }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AuthScreen(
    onLogin: (String, String, (Boolean, String) -> Unit) -> Unit,
    onSignup: (String, String, (Boolean, String) -> Unit) -> Unit
) {
    var isLogin by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Intern Issue Tracker",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        if (!isLogin) {
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Confirm Password") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        if (message.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(message, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                message = ""

                if (email.isBlank() || password.isBlank()) {
                    message = "Enter email and password"
                } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
                    message = "Enter a valid email address"
                } else if (password.length < 6) {
                    message = "Password must be at least 6 characters"
                } else if (!isLogin && password != confirmPassword) {
                    message = "Passwords do not match"
                } else {
                    loading = true

                    val callback: (Boolean, String) -> Unit = { success, result ->
                        loading = false
                        if (!success) message = result
                    }

                    if (isLogin) {
                        onLogin(email.trim(), password, callback)
                    } else {
                        onSignup(email.trim(), password, callback)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !loading
        ) {
            Text(
                if (loading) "Please wait..."
                else if (isLogin) "Login"
                else "Create Account"
            )
        }

        TextButton(
            onClick = {
                isLogin = !isLogin
                message = ""
                confirmPassword = ""
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                if (isLogin) "Don't have an account? Sign Up"
                else "Already have an account? Login"
            )
        }
    }
}

@Composable
fun HomeScreen(
    issues: List<Issue>,
    onReport: () -> Unit,
    onTickets: () -> Unit
) {
    val pending = issues.count { it.status == "Pending" }
    val inProgress = issues.count { it.status == "In Progress" }
    val resolved = issues.count { it.status == "Resolved" }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Intern Dashboard",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(8.dp))
        Text("Welcome! Report and track your issues easily.")

        Spacer(Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("Total", issues.size, Modifier.weight(1f))
            StatCard("Pending", pending, Modifier.weight(1f))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("In Progress", inProgress, Modifier.weight(1f))
            StatCard("Resolved", resolved, Modifier.weight(1f))
        }

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = onReport,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Report New Issue")
        }

        OutlinedButton(
            onClick = onTickets,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Track My Tickets")
        }
    }
}

@Composable
fun ReportScreen(
    onSubmit: (String, String, String) -> Unit,
    loading: Boolean
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("Medium") }
    var error by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Report an Issue",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = title,
            onValueChange = {
                title = it
                error = ""
            },
            label = { Text("Issue Title") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = description,
            onValueChange = {
                description = it
                error = ""
            },
            label = { Text("Describe your issue") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 4
        )

        Spacer(Modifier.height(16.dp))
        Text("Select Issue Priority")

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Low", "Medium", "High").forEach {
                FilterChip(
                    selected = priority == it,
                    onClick = { priority = it },
                    label = { Text(it) }
                )
            }
        }

        if (error.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(error, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                if (title.isBlank() || description.isBlank()) {
                    error = "Please enter both title and description"
                } else if (title.trim().length < 3) {
                    error = "Title must contain at least 3 characters"
                } else if (description.trim().length < 10) {
                    error = "Description must contain at least 10 characters"
                } else {
                    error = ""
                    onSubmit(title.trim(), description.trim(), priority)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !loading
        ) {
            Text(if (loading) "Submitting..." else "Submit Issue")
        }
    }
}

@Composable
fun TicketsScreen(
    issues: List<Issue>,
    db: FirebaseFirestore,
    userEmail: String,
    userRole: String
) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "My Tickets",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(12.dp))

        if (issues.isEmpty()) {
            Text("No tickets reported yet.")
        } else {
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(issues, key = { it.id }) { issue ->
                    IssueCard(
                        issue = issue,
                        db = db,
                        userEmail = userEmail,
                        userRole = userRole
                    )
                }
            }
        }
    }
}

@Composable
fun AdminScreen(
    issues: List<Issue>,
    db: FirebaseFirestore,
    userEmail: String,
    userRole: String,
    onStatusChange: (String, String) -> Unit,
    onDelete: (String) -> Unit
) {
    var searchText by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    var selectedPriority by remember { mutableStateOf("All") }
    var issueToDelete by remember { mutableStateOf<Issue?>(null) }

    val pending = issues.count { it.status == "Pending" }
    val inProgress = issues.count { it.status == "In Progress" }
    val resolved = issues.count { it.status == "Resolved" }

    val filteredIssues = issues.filter { issue ->

        val matchesSearch =
            issue.title.contains(searchText, true) ||
                    issue.description.contains(searchText, true) ||
                    issue.reporterEmail.contains(searchText, true) ||
                    issue.id.contains(searchText, true)

        val matchesStatus =
            selectedFilter == "All" || issue.status == selectedFilter

        val matchesPriority =
            selectedPriority == "All" || issue.priority == selectedPriority

        matchesSearch && matchesStatus && matchesPriority
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Admin Dashboard",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("Total", issues.size, Modifier.weight(1f))
            StatCard("Pending", pending, Modifier.weight(1f))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("In Progress", inProgress, Modifier.weight(1f))
            StatCard("Resolved", resolved, Modifier.weight(1f))
        }

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = searchText,
            onValueChange = { searchText = it },
            label = { Text("Search tickets") },
            placeholder = { Text("Title, description, email or ID") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Text("Filter by Status")

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("All", "Pending", "In Progress", "Resolved").forEach {
                FilterChip(
                    selected = selectedFilter == it,
                    onClick = { selectedFilter = it },
                    label = { Text(it) }
                )
            }
        }

        Text("Filter by Priority")

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("All", "Low", "Medium", "High").forEach {
                FilterChip(
                    selected = selectedPriority == it,
                    onClick = { selectedPriority = it },
                    label = { Text(it) }
                )
            }
        }

        Text("Matching Tickets: ${filteredIssues.size}")

        if (filteredIssues.isEmpty()) {
            Text("No matching tickets found.")
        } else {
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredIssues, key = { it.id }) { issue ->

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {

                        IssueCard(
                            issue = issue,
                            db = db,
                            userEmail = userEmail,
                            userRole = userRole
                        )

                        Text(
                            "Reported by: ${issue.reporterEmail}",
                            style = MaterialTheme.typography.bodySmall
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    onStatusChange(issue.id, "In Progress")
                                },
                                modifier = Modifier.weight(1f),
                                enabled = issue.status != "In Progress"
                            ) {
                                Text("In Progress")
                            }

                            Button(
                                onClick = {
                                    onStatusChange(issue.id, "Resolved")
                                },
                                modifier = Modifier.weight(1f),
                                enabled = issue.status != "Resolved"
                            ) {
                                Text("Resolve")
                            }
                        }

                        TextButton(
                            onClick = { issueToDelete = issue },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "Delete Ticket",
                                color = MaterialTheme.colorScheme.error
                            )
                        }

                        HorizontalDivider()
                    }
                }
            }
        }
    }

    issueToDelete?.let { issue ->
        AlertDialog(
            onDismissRequest = { issueToDelete = null },
            title = { Text("Delete Ticket?") },
            text = {
                Text("Are you sure you want to delete '${issue.title}'?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDelete(issue.id)
                        issueToDelete = null
                    }
                ) {
                    Text(
                        "Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { issueToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun StatCard(
    title: String,
    count: Int,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title)
            Text(
                count.toString(),
                style = MaterialTheme.typography.headlineMedium
            )
        }
    }
}

@Composable
fun IssueCard(
    issue: Issue,
    db: FirebaseFirestore,
    userEmail: String,
    userRole: String
) {
    var showDetails by remember { mutableStateOf(false) }
    var showComments by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {

            Text("Ticket #${issue.id}")

            Text(
                issue.title,
                style = MaterialTheme.typography.titleMedium
            )

            Text("Priority: ${issue.priority}")
            Text("Status: ${issue.status}")
            Text("Submitted: ${formatIssueDate(issue.createdAt)}")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TextButton(
                    onClick = { showDetails = true }
                ) {
                    Text("Details")
                }

                TextButton(
                    onClick = { showHistory = true }
                ) {
                    Text("Status History")
                }
            }

            Button(
                onClick = { showComments = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Comments / Replies")
            }
        }
    }

    if (showDetails) {
        AlertDialog(
            onDismissRequest = { showDetails = false },
            title = { Text("Ticket Details") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Ticket ID: ${issue.id}")
                    Text("Title: ${issue.title}")
                    Text("Description: ${issue.description}")
                    Text("Priority: ${issue.priority}")
                    Text("Status: ${issue.status}")
                    Text("Submitted: ${formatIssueDate(issue.createdAt)}")
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetails = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("Ticket Status History") },
            text = {
                Column {
                    Text(issue.title)
                    Spacer(Modifier.height(12.dp))

                    if (issue.statusHistory.isEmpty()) {
                        Text("No status history available.")
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 300.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(issue.statusHistory) { entry ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(10.dp)) {
                                        Text(
                                            entry.status,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text("Changed by: ${entry.changedBy}")
                                        Text(formatIssueDate(entry.changedAt))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistory = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showComments) {
        IssueCommentsDialog(
            issue = issue,
            db = db,
            userEmail = userEmail,
            userRole = userRole,
            onDismiss = { showComments = false }
        )
    }
}

@Composable
fun IssueCommentsDialog(
    issue: Issue,
    db: FirebaseFirestore,
    userEmail: String,
    userRole: String,
    onDismiss: () -> Unit
) {
    var comments by remember { mutableStateOf(listOf<TicketComment>()) }
    var message by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    DisposableEffect(issue.id) {
        val registration = db.collection("issues")
            .document(issue.id)
            .collection("comments")
            .orderBy("createdAt")
            .addSnapshotListener { snapshot, exception ->

                if (exception != null) {
                    error = exception.message ?: "Comments loading failed"
                } else if (snapshot != null) {
                    comments = snapshot.documents.map { doc ->

                        val timestamp = doc.getTimestamp("createdAt")

                        TicketComment(
                            id = doc.id,
                            message = doc.getString("message") ?: "",
                            senderEmail = doc.getString("senderEmail") ?: "",
                            senderRole = doc.getString("senderRole") ?: "",
                            createdAt = timestamp?.toDate()?.time ?: 0L
                        )
                    }
                }
            }

        onDispose {
            registration.remove()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ticket Comments") },
        text = {
            Column(Modifier.fillMaxWidth()) {

                Text(
                    issue.title,
                    style = MaterialTheme.typography.titleMedium
                )

                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 250.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (comments.isEmpty()) {
                        item {
                            Text("No comments yet. Start the conversation!")
                        }
                    }

                    items(comments, key = { it.id }) { comment ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                Text(
                                    "${comment.senderEmail} (${comment.senderRole})",
                                    style = MaterialTheme.typography.labelLarge
                                )

                                Text(comment.message)

                                Text(
                                    formatIssueDate(comment.createdAt),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                OutlinedTextField(
                    value = message,
                    onValueChange = {
                        message = it
                        error = ""
                    },
                    label = { Text("Write a comment or reply") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                if (error.isNotEmpty()) {
                    Text(
                        error,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = message.isNotBlank() && !sending,
                onClick = {

                    val currentUid =
                        FirebaseAuth.getInstance().currentUser?.uid

                    if (currentUid == null) {
                        error = "Please login again"
                        return@Button
                    }

                    sending = true
                    error = ""

                    val commentData = hashMapOf(
                        "message" to message.trim(),
                        "senderEmail" to userEmail,
                        "senderRole" to userRole,
                        "senderUid" to currentUid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )

                    db.collection("issues")
                        .document(issue.id)
                        .collection("comments")
                        .add(commentData)
                        .addOnSuccessListener {
                            message = ""
                            sending = false
                        }
                        .addOnFailureListener {
                            sending = false
                            error = it.message ?: "Comment could not be sent"
                        }
                }
            ) {
                Text(if (sending) "Sending..." else "Send")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
